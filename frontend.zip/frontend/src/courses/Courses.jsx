import React from 'react'
import Footer from '../components/Footer'
import Navabar from '../components/Navabar'
import Ourse from '../components/Ourse'



function Courses() {
  return (
    <>
    <Navabar />
    <div className='min-h-screen'>
        <Ourse />
    </div>
    <Footer />
    </>
  )
}

export default Courses
