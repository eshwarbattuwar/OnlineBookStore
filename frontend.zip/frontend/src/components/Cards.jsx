import React, { useState } from 'react';

function Cards({ item }) {
  const [cart, setCart] = useState([]);

  const addToCart = () => {
    setCart([...cart, item]);
  };

  const buyNow = () => {
    // Logic for handling buy now action
    console.log("Buy Now clicked:", item);
  };

  return (
    <>
      <div className='mt-4 my-4 p-3'>
        <div className="card w-92 bg-base-100 shadow-xl hover:scale-105 duration-200 ">
          <figure><img src={item.image} alt="Books" /></figure>
          <div className="card-body">
            <h2 className="card-title">
              {item.name}
              <div className="badge badge-secondary">{item.category}</div>
            </h2>
            <p>{item.title}</p>
            <div className="card-actions flex justify-between items-center">
              <button onClick={addToCart} className="cursor-pointer px-2 py-1 rounded-full border-[2px] hover:bg-pink-500 duration-200 hover:text-white">Add to Cart</button>
              <div className="badge badge-outline px-2 py-1">${item.price}</div> 
              <button onClick={buyNow} className="cursor-pointer px-2 py-1 rounded-full border-[2px] hover:bg-pink-500 duration-200 hover:text-white">Buy Now</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Cards;
